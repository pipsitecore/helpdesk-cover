A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/vpxQQE.

 A table that uses Materialize http://materializecss.com/ and Angular.js.

This was used with PHP and mySQL on my local WAMP server.  I may update functions to use JSON shortly.

Credit:

Pagination Directive by Michael Bromley
 https://github.com/michaelbromley/angularUtils/tree/master/src/directives/pagination
 
Phone Format Directive by Philip Da Silva
https://codepen.io/rpdasilva/pen/DpbFf

Sort and Filter a Table Using Angular Tutorial by Scotch.Io
https://scotch.io/tutorials/sort-and-filter-a-table-using-angular

PHP, MySQL and AngularJS CRUD Tutorial by Mike Dalisay 
https://www.codeofaninja.com/2015/12/angularjs-crud-example-php.html

Name Regex by maček
http://stackoverflow.com/questions/2385701/regular-expression-for-first-and-last-name